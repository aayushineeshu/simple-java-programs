import java.util.Scanner;
public class pattern {
    public static void main(String a[])
    { 
        int i,j;
        int n;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter n");
        n=sc.nextInt();
        
 
        // This is upper half of pattern
        for (i = 1; i <= n; i++) {
            for (j = 1; j <= (2 * n); j++) {
                 
                // Left part of pattern
                if (i > (n - j + 1))
                    System.out.print(" ");
                else
                    System.out.print("*");
 
                // Right part of pattern
                if ((i + n) > j)
                    System.out.print(" ");
                else
                    System.out.print("*");
            }
             
            System.out.println("");
        }for (i = 1; i <= n; i++) {
            for (j = 1; j <= (2 * n); j++) {
                 
                // Right Part of pattern
                if (i < j)
                    System.out.print(" ");
                else
                    System.out.print("*");
 
                // Left Part of pattern
                if (i <= ((2 * n) - j))
                    System.out.print(" ");
                else
                    System.out.print("*");
            }
             
            System.out.println("");
        }
    }
 
    
    
    
    
    }

