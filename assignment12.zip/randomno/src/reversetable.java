import java.util.Scanner;
public class reversetable {
    public static void main(String ar[])
    {
        int a;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number:");
        a=sc.nextInt();
        for(int i=10;i>=1;i--)
        {
            System.out.println(""+i*a);
        }
       
    
}}
