


public class sumavrg {
public static void main(String ar[])
{    int sum=0,count=0;
 float avrg=0;
    for(int i=500;i<=600;i++)
    {
        if(i%5==0){
          sum=sum+i;
          count++;
          avrg=sum/count;
            System.out.println(" "+i);
        }
    }System.out.println("sum is "+sum);
    System.out.println("average is:"+avrg);
}
}
