import java.util.Scanner;
public class rectangle {
    public static void main (String ar[])
    {
        float length,breadth;
        double area;
        float perimeter;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the length");
        length=sc.nextFloat();
        System.out.println("enter the breadth");
        breadth=sc.nextFloat();
        area=length*breadth;
        System.out.println("Area of rectangle is:"+area);
        perimeter=2*length*breadth;
        System.out.println("Perimeter of the rectangle is:"+perimeter);
        
    }
}
