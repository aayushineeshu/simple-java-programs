import java.util.Scanner;
public class vowel {
    public static void main(String ar[])
    {
        char c;
        Scanner sc=new Scanner(System.in);
        System.out.print("enter the c\t");
        c=sc.next().charAt(0);
        switch(c)
        {   case 'A':
            case 'a':System.out.println("vowel A");
                break;
            case 'E':
            case 'e':System.out.println("vowel E");
                break;
            case 'I':
                case 'i':System.out.println("vowel I");
                    break;
                case 'O':
                    case 'o':System.out.println("vowel O");
                        break;
                    case 'U':
                        case 'u':System.out.println("vowel U");
                            break;
                    
                 default: System.out.println("not a vowel");
                    break;
                   
        }
        
    }
    
}
