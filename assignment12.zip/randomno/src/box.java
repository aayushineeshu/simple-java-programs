

import java.util.Scanner;
public class box {
    public static void main(String arg[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the N:");
        int n=sc.nextInt();
        char s='*';
        for(int i=1;i<=n;i++)
        {
            System.out.print(s);
        }
        for(int j=1;j<=n/2;j++)
        {
            System.out.println(s);
            for(int i=1;i<=n;i++)
        {
            System.out.print(s);
        }
        }
    }
}
