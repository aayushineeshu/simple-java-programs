import java.util.Scanner;
public class interest {
    public static void main (String a[]){
        
        float principle,rateofinterest,time;
        
        Scanner sc=new Scanner(System.in);
        System.out.println("principle is:");
        principle=sc.nextInt();
        System.out.println("time is:");
        rateofinterest=sc.nextInt();
        System.out.println("rate of interest is:");
        time=sc.nextFloat();
        float si;
        si= principle*rateofinterest*time/100;
        System.out.println("simple interest is:"+si);
        double ci;
        ci=principle*(Math.pow(1+rateofinterest/100, time));
        System.out.println("compound interest is:"+ci);
    }
}
