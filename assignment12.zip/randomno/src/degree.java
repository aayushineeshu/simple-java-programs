import java.util.Scanner;
public class degree {
    public static void main(String a[])
    {
        float centigrade,fahrenheit;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the centigrade:");
        centigrade=sc.nextFloat();
        
        fahrenheit=(centigrade*9/5)+32;
        System.out.println("the conversion result to fahrenheit is:"+fahrenheit);
    }
    
}
