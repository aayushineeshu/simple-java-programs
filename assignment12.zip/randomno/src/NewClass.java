
public class NewClass {
    public static void main(String abc[])
    {
        int myApp;
        String A ="hello";
        float startHad;
        double a=10.5;
        float b=10.5f;
b=(int)a;
System.out.println(b);
        System.out.println("aayushi");
        //System.out.println(" ");
        System.out.println("sunidhi");
    }
}
