
public class evennum {
    public static void main(String arg[])
    {
        int i,c;
       System.out.println("even numbers between 100 to 200");
        for(i=100;i<=200;i++)
        {if(i%2==0)
        {
            System.out.println(" "+i);
        }
        System.out.println("multiples of between 100 to 300");
        for(c=100;c<=300;c++){
            if(c%3==0)
            {
                System.out.println(""+c);
            }
        }
        }
    }
}
