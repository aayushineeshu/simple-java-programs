/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aayushie
 */
import java.util.Scanner;
public class circle {
     public static void main (String a[])
{  float radius,area=0,circum=0;
    
Scanner sc =new Scanner(System.in);
System.out.println("enter the radius of the circle");
radius=sc.nextFloat();
 
area=  3.14f*radius*radius;
circum= 2*3.14f*radius;
System.out.println("area of the circle is"+area);
System.out.println("circumference of the circle is"+circum);
}
    
}
