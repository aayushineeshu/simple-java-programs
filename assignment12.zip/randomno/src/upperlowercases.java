

import java.util.Scanner;
public class upperlowercases {
    public static void main(String args[])
    {
        char c;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the character");
        c=sc.next().charAt(0);
       if(c>='A')
       {
       if(c<='Z')
               System.out.println("upper case");
                   
           
       
           
       }if(c>='a')
       {  
        if(c<='z')
          System.out.println("lower case");
    }
        if(c>=10)
            if(c<=64)
    {
        System.out.println("special character");
    }
    }
}
