import java.util.Scanner;
public class details {
    public static void main(String args[])
    { String s;
        String name= "Aayushi jha";
        System.out.println("name:"+name);
         System.out.println("enter the string:");
       Scanner sc=new Scanner(System.in);
       s=sc.nextLine();
      
       
       
    }
}
