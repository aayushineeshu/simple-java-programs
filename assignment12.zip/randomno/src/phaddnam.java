import java.util.Scanner;
public class phaddnam {
    public static void main(String args[])
    {
        String name,address,phno;
        
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the name");
        name=sc.nextLine();
        System.out.println("enter the address");
        address=sc.nextLine();
        System.out.println("enter the phone number");
        phno=sc.nextLine();
        
        System.out.println("name:"+name);
        System.out.println("address:"+address);
        System.out.println("phone number:"+phno);
    }
    
}
